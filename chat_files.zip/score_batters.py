#!/usr/bin/env python3
"""
score_batters.py — Composite 0-100 scoring engine for Daily HR Bet.

Scores each batter across 5 factors (power, matchup, park, form, weather)
and produces a ranked list. Supports multiple weight configurations.

Usage:
    python score_batters.py --date 2024-07-15
    python score_batters.py --date 2024-07-15 --config power_heavy
"""

import argparse
import json
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Weight Configurations
# ---------------------------------------------------------------------------

WEIGHT_CONFIGS = {
    "default":       {"power": 0.30, "matchup": 0.25, "park": 0.20, "form": 0.15, "weather": 0.10},
    "matchup_heavy": {"power": 0.20, "matchup": 0.40, "park": 0.15, "form": 0.15, "weather": 0.10},
    "power_heavy":   {"power": 0.45, "matchup": 0.20, "park": 0.15, "form": 0.12, "weather": 0.08},
    "park_heavy":    {"power": 0.20, "matchup": 0.20, "park": 0.35, "form": 0.15, "weather": 0.10},
    "form_heavy":    {"power": 0.20, "matchup": 0.20, "park": 0.15, "form": 0.35, "weather": 0.10},
    "no_weather":    {"power": 0.33, "matchup": 0.28, "park": 0.22, "form": 0.17, "weather": 0.00},
}


# ---------------------------------------------------------------------------
# Normalization helpers
# ---------------------------------------------------------------------------

def min_max_scale(value: float, min_val: float, max_val: float) -> float:
    """Scale a value to 0-100 range."""
    if max_val == min_val:
        return 50.0
    return max(0, min(100, (value - min_val) / (max_val - min_val) * 100))


def percentile_rank(value: float, values: list) -> float:
    """Return percentile rank (0-100) of value within a list."""
    if not values:
        return 50.0
    arr = np.array(values)
    return float(np.searchsorted(np.sort(arr), value) / len(arr) * 100)


# ---------------------------------------------------------------------------
# Factor scoring functions
# ---------------------------------------------------------------------------

def score_power(batter: dict) -> float:
    """
    Factor 1: Power Profile (barrel%, exit velo, HR/FB, ISO as xHR proxy).
    Returns 0-100.
    """
    scores = []

    # Barrel%: 0-25% → 0-100
    barrel = batter.get("barrel_pct", 0)
    if barrel is not None:
        scores.append(min_max_scale(barrel, 0, 25))

    # Exit Velocity: 80-100 mph → 0-100
    ev = batter.get("exit_velo", 0)
    if ev and ev > 0:
        scores.append(min_max_scale(ev, 80, 100))

    # HR/FB%: 0-30% → 0-100
    hr_fb = batter.get("hr_fb_pct", 0)
    if hr_fb is not None:
        # Handle both decimal (0.15) and percentage (15.0) formats
        if hr_fb < 1:
            hr_fb *= 100
        scores.append(min_max_scale(hr_fb, 0, 30))

    # ISO as power proxy: .100-.350 → 0-100
    iso = batter.get("iso", 0)
    if iso and iso > 0:
        scores.append(min_max_scale(iso, 0.100, 0.350))

    return float(np.mean(scores)) if scores else 50.0


def score_matchup(batter: dict, pitcher: dict) -> float:
    """
    Factor 2: Matchup quality (pitcher HR/9, hard-hit% allowed, batter vs hand).
    Returns 0-100.
    """
    scores = []

    # Pitcher HR/9: 0-3.0 → 0-100 (higher = better for batter)
    hr9 = pitcher.get("hr_per_9", 1.2)
    if hr9 is not None:
        scores.append(min_max_scale(hr9, 0, 3.0))

    # Pitcher hard-hit% allowed: 25-50% → 0-100
    hh = pitcher.get("hard_hit_pct_allowed", 35)
    if hh is not None:
        scores.append(min_max_scale(hh, 25, 50))

    # Batter wOBA vs hand: .250-.450 → 0-100
    woba = batter.get("woba_vs_hand", batter.get("woba", 0.320))
    if woba:
        scores.append(min_max_scale(woba, 0.250, 0.450))

    # Platoon advantage bonus: +10 if batter has platoon advantage
    batter_hand = batter.get("bats", "R")
    pitcher_hand = pitcher.get("throws", "R")
    platoon_bonus = 10 if batter_hand != pitcher_hand else 0

    base = float(np.mean(scores)) if scores else 50.0
    return min(100, base + platoon_bonus)


def score_park(batter: dict, venue: str, park_factors: pd.DataFrame) -> float:
    """
    Factor 3: Park Factor for HRs.
    Returns 0-100.
    """
    pf = 100  # neutral default
    if not park_factors.empty and venue:
        match = park_factors[park_factors["venue"] == venue]
        if not match.empty:
            pf = match.iloc[0]["hr_park_factor"]

    # Scale: 70-130 → 0-100
    base = min_max_scale(pf, 70, 130)

    # Handedness adjustment (simplified: LHB slight boost in RF-short parks)
    bats = batter.get("bats", "R")
    if bats == "L" and venue in ["Yankee Stadium", "Fenway Park", "Great American Ball Park"]:
        base = min(100, base + 5)
    elif bats == "R" and venue in ["Wrigley Field", "Coors Field"]:
        base = min(100, base + 3)

    return base


def score_form(batter: dict) -> float:
    """
    Factor 4: Recent form (last 14 days).
    Returns 0-100.
    """
    scores = []

    # HRs in last 14 days: 0-5+ → 0-100
    recent_hr = batter.get("recent_hr_14d", 0)
    scores.append(min_max_scale(recent_hr, 0, 5))

    # Recent barrel%: 0-25% → 0-100
    recent_barrel = batter.get("recent_barrel_pct_14d", 0)
    if recent_barrel is not None:
        scores.append(min_max_scale(recent_barrel, 0, 25))

    # Exit velo trend (recent - season avg): -5 to +5 → 0-100
    ev_trend = batter.get("ev_trend_14d", 0)
    scores.append(min_max_scale(ev_trend, -5, 5))

    return float(np.mean(scores)) if scores else 50.0


def score_weather(weather: dict) -> float:
    """
    Factor 5: Weather conditions.
    Returns 0-100.
    """
    if weather.get("dome", False):
        return 50.0  # Neutral for dome stadiums

    # Temperature: 50-100°F → 0-100
    temp = weather.get("temperature_f", 75)
    temp_score = min_max_scale(temp, 50, 100)

    # Wind scoring based on speed and direction
    wind_mph = weather.get("wind_mph", 5)
    wind_dir = weather.get("wind_direction_deg", 0)

    # Simplified wind model:
    # 0°/360° = N (blowing out to CF), 180° = S (blowing in)
    # Wind blowing out (315-45°) with speed > 5 = good for HRs
    if wind_dir is None:
        wind_score = 50
    elif (wind_dir >= 315 or wind_dir <= 45):  # blowing out
        wind_score = min(100, 50 + wind_mph * 4)
    elif 135 <= wind_dir <= 225:  # blowing in
        wind_score = max(0, 50 - wind_mph * 4)
    else:  # crosswind
        wind_score = 50 + (wind_mph * 1)  # slight boost for crosswinds

    return temp_score * 0.4 + wind_score * 0.6


# ---------------------------------------------------------------------------
# Composite scoring
# ---------------------------------------------------------------------------

def compute_composite(
    batter: dict,
    pitcher: dict,
    venue: str,
    weather: dict,
    park_factors: pd.DataFrame,
    config_name: str = "default",
) -> dict:
    """
    Compute composite score for a single batter.
    Returns dict with factor scores and weighted composite.
    """
    weights = WEIGHT_CONFIGS[config_name]

    power = score_power(batter)
    matchup = score_matchup(batter, pitcher)
    park = score_park(batter, venue, park_factors)
    form = score_form(batter)
    weather_score = score_weather(weather)

    composite = (
        weights["power"] * power
        + weights["matchup"] * matchup
        + weights["park"] * park
        + weights["form"] * form
        + weights["weather"] * weather_score
    )

    return {
        "name": batter.get("name", "Unknown"),
        "team": batter.get("team", ""),
        "bats": batter.get("bats", ""),
        "venue": venue,
        "power_score": round(power, 1),
        "matchup_score": round(matchup, 1),
        "park_score": round(park, 1),
        "form_score": round(form, 1),
        "weather_score": round(weather_score, 1),
        "composite": round(composite, 1),
        "config": config_name,
    }


def score_all_batters(
    batters: list[dict],
    pitchers: dict,  # keyed by game_pk or team
    games: list[dict],
    weather_data: dict,
    park_factors: pd.DataFrame,
    config_name: str = "default",
) -> list[dict]:
    """
    Score all batters for a given day.
    Returns sorted list (highest composite first).
    """
    results = []
    for batter in batters:
        game_pk = batter.get("game_pk")
        venue = batter.get("venue", "")
        pitcher = pitchers.get(batter.get("opposing_pitcher_id"), {})
        weather = weather_data.get(game_pk, {})

        score = compute_composite(batter, pitcher, venue, weather, park_factors, config_name)
        score["game_pk"] = game_pk
        score["player_id"] = batter.get("player_id")
        results.append(score)

    # Sort by composite score descending
    results.sort(key=lambda x: x["composite"], reverse=True)
    return results


def select_top_picks(scored: list[dict], n: int = 8, max_per_game: int = 2, min_score: float = 0) -> list[dict]:
    """
    Select top N picks with diversification constraint.
    Max 2 batters from same game.
    """
    picks = []
    game_counts = {}
    seen_names = set()

    for batter in scored:
        if len(picks) >= n:
            break
        if batter["composite"] < min_score:
            continue

        name = batter.get("name", "")
        if name in seen_names:
            continue

        gp = batter.get("game_pk")
        if game_counts.get(gp, 0) >= max_per_game:
            continue

        picks.append(batter)
        seen_names.add(name)
        game_counts[gp] = game_counts.get(gp, 0) + 1

    return picks


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Score batters for HR parlay")
    parser.add_argument("--date", required=True, help="Date (YYYY-MM-DD)")
    parser.add_argument("--config", default="default", choices=WEIGHT_CONFIGS.keys())
    parser.add_argument("--top", type=int, default=8, help="Number of picks")
    parser.add_argument("--output", default=None, help="Output JSON path")
    args = parser.parse_args()

    data_dir = Path(__file__).parent.parent / "data"
    data_file = data_dir / f"daily_{args.date}.json"

    if not data_file.exists():
        print(f"No data file found for {args.date}. Run fetch_daily_data.py first.")
        sys.exit(1)

    with open(data_file) as f:
        data = json.load(f)

    print(f"Scoring batters for {args.date} with config '{args.config}'")
    # In live mode, this would use the full fetched data
    # For now, print summary
    print(f"Games: {len(data['games'])}")
    print(f"Config weights: {WEIGHT_CONFIGS[args.config]}")


if __name__ == "__main__":
    main()