#!/usr/bin/env python3
"""
generate_picks.py — Generate today's 8-pick HR parlay card.

LIVE MODE (default): Fetches real data from MLB Stats API (lineups, probable
pitchers), Open-Meteo (weather), and pybaseball/FanGraphs (Statcast metrics).
Falls back to offline simulation if any API is unreachable.

OFFLINE MODE (--offline): Uses hardcoded 2025 season data with simulated
matchups. Useful for backtesting or when APIs are blocked.

Usage:
    # Live — pulls real lineups, pitchers, weather for today
    python generate_picks.py --date 2026-03-26

    # Offline fallback
    python generate_picks.py --date 2026-03-26 --offline

    # Custom tier blend
    python generate_picks.py --date 2026-03-26 --combo 2,3,3

Requirements (live mode):
    pip install pybaseball pandas numpy requests
"""

import argparse
import json
import sys
import hashlib
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from score_batters import WEIGHT_CONFIGS, compute_composite, select_top_picks
from fetch_daily_data import (
    DOME_STADIUMS,
    VENUE_COORDS,
    get_hardcoded_park_factors,
    get_schedule,
    get_weather,
    get_roster,
)
from mlb_2025_tiers import (
    ALL_TIERS,
    PITCHERS_2025,
    get_tier_for_batter,
    get_all_batters_lookup,
)

# ---------------------------------------------------------------------------
# Optimized configs from 2025 backtesting
# ---------------------------------------------------------------------------
TIER_CONFIGS = {1: "matchup_heavy", 2: "default", 3: "power_heavy"}
TIER_POINTS = {1: 1, 2: 3, 3: 9}

VENUES = [
    ("NYY", "Yankee Stadium"), ("BOS", "Fenway Park"), ("TOR", "Rogers Centre"),
    ("BAL", "Oriole Park at Camden Yards"), ("TB", "Tropicana Field"),
    ("CLE", "Progressive Field"), ("MIN", "Target Field"), ("KC", "Kauffman Stadium"),
    ("DET", "Comerica Park"), ("CWS", "Guaranteed Rate Field"),
    ("HOU", "Minute Maid Park"), ("TEX", "Globe Life Field"),
    ("SEA", "T-Mobile Park"), ("LAA", "Angel Stadium"), ("OAK", "Oakland Coliseum"),
    ("ATL", "Truist Park"), ("PHI", "Citizens Bank Park"), ("NYM", "Citi Field"),
    ("MIA", "loanDepot park"), ("WSH", "Nationals Park"),
    ("MIL", "American Family Field"), ("CHC", "Wrigley Field"),
    ("STL", "Busch Stadium"), ("CIN", "Great American Ball Park"),
    ("PIT", "PNC Park"), ("LAD", "Dodger Stadium"), ("SD", "Petco Park"),
    ("SF", "Oracle Park"), ("ARI", "Chase Field"), ("COL", "Coors Field"),
]


# ---------------------------------------------------------------------------
# LIVE MODE — real data from APIs
# ---------------------------------------------------------------------------

def try_fetch_statcast_recent(player_id: int, days: int = 14) -> dict:
    """Try to get recent Statcast data for form scoring. Returns dict or empty."""
    try:
        from pybaseball import statcast_batter
        end = datetime.now()
        start = end - timedelta(days=days)
        df = statcast_batter(
            start.strftime("%Y-%m-%d"),
            end.strftime("%Y-%m-%d"),
            player_id,
        )
        if df.empty:
            return {}
        # Compute recent form metrics
        hr_events = df[df["events"] == "home_run"]
        barrels = df[df["launch_speed_angle"].fillna(0) >= 6] if "launch_speed_angle" in df.columns else df.head(0)
        recent_ev = df["launch_speed"].mean() if "launch_speed" in df.columns else None
        season_ev_approx = 88.0  # rough league average
        return {
            "recent_hr_14d": len(hr_events),
            "recent_barrel_pct_14d": len(barrels) / max(len(df), 1) * 100,
            "ev_trend_14d": (recent_ev - season_ev_approx) if recent_ev else 0,
        }
    except Exception:
        return {}


def try_fetch_pitcher_season_stats(pitcher_name: str, season: int) -> dict:
    """Try to get pitcher season stats from FanGraphs. Returns dict or empty."""
    try:
        from pybaseball import pitching_stats
        df = pitching_stats(season, qual=10)
        match = df[df["Name"] == pitcher_name]
        if match.empty:
            # Try partial match
            match = df[df["Name"].str.contains(pitcher_name.split()[-1], na=False)]
        if match.empty:
            return {}
        row = match.iloc[0]
        return {
            "name": pitcher_name,
            "hr_per_9": row.get("HR/9", 1.2),
            "era": row.get("ERA", 4.0),
            "hard_hit_pct_allowed": row.get("HardHit%", 35),
            "throws": row.get("Throws", "R") if "Throws" in row.index else "R",
            "k_per_9": row.get("K/9", 8.0),
        }
    except Exception:
        return {}


def fetch_live_slate(date_str: str) -> dict:
    """
    Fetch today's real MLB slate: games, lineups, pitchers, weather.
    Returns a dict with all data needed for scoring, or None if APIs fail.
    """
    print(f"  [LIVE] Fetching MLB schedule for {date_str}...")
    try:
        games = get_schedule(date_str)
    except Exception as e:
        print(f"  [LIVE] MLB Stats API failed: {e}")
        return None

    if not games:
        print(f"  [LIVE] No games found for {date_str}")
        return None

    print(f"  [LIVE] Found {len(games)} games")

    # Get weather for each game
    weather_data = {}
    for g in games:
        venue = g["venue"]
        game_time = g.get("game_time", "")
        try:
            weather_data[g["game_pk"]] = get_weather(venue, game_time)
        except Exception:
            is_dome = venue in DOME_STADIUMS
            weather_data[g["game_pk"]] = {
                "temperature_f": 72 if is_dome else 75,
                "wind_mph": 0 if is_dome else 5,
                "wind_direction_deg": 0,
                "dome": is_dome,
            }

    # Try to fetch rosters for confirmed lineups
    rosters = {}
    for g in games:
        for side in ["home", "away"]:
            team_id = g[f"{side}_team_id"]
            if team_id not in rosters:
                try:
                    rosters[team_id] = get_roster(team_id, date_str)
                except Exception:
                    rosters[team_id] = []

    # Build pitcher lookup — try FanGraphs first, fall back to offline data
    pitcher_offline = {p["name"]: p for p in PITCHERS_2025}
    pitcher_lookup = {}
    season = int(date_str[:4])
    fetched_fg = False

    for g in games:
        for side in ["home", "away"]:
            pname = g.get(f"{side}_pitcher_name", "TBD")
            pid = g.get(f"{side}_pitcher_id")
            if pname == "TBD" or pname in pitcher_lookup:
                continue

            # Try FanGraphs for live stats (once)
            if not fetched_fg:
                live_stats = try_fetch_pitcher_season_stats(pname, season)
                if live_stats:
                    pitcher_lookup[pname] = live_stats
                    continue
                else:
                    # If first attempt fails, likely all will — skip FanGraphs
                    fetched_fg = True

            # Offline fallback
            if pname in pitcher_offline:
                pitcher_lookup[pname] = pitcher_offline[pname]
            else:
                # Unknown pitcher — use league average
                pitcher_lookup[pname] = {
                    "name": pname,
                    "hr_per_9": 1.2,
                    "hard_hit_pct_allowed": 35,
                    "throws": "R",
                }

    return {
        "games": games,
        "weather": weather_data,
        "rosters": rosters,
        "pitchers": pitcher_lookup,
    }


def score_live_slate(slate: dict, date_str: str, tier: int, config_name: str, pf) -> list:
    """
    Score all batters in a tier against the live slate.
    Matches batters to their actual games/opponents from the schedule.
    """
    batter_lookup = get_all_batters_lookup()
    tier_batters = ALL_TIERS[tier]
    batter_names = {b["name"] for b in tier_batters}
    batter_by_name = {b["name"]: b for b in tier_batters}

    # Map team names to games
    team_to_game = {}
    for g in slate["games"]:
        team_to_game[g["home_team"]] = g
        team_to_game[g["away_team"]] = g

    all_scored = []
    season = int(date_str[:4])

    for b in tier_batters:
        batter_team = b.get("team", "")
        # Find game for this batter's team
        game = None
        for g in slate["games"]:
            # Match by team abbreviation in the game's team names
            ht = g.get("home_team", "")
            at = g.get("away_team", "")
            # Try matching abbreviation to full name
            if (batter_team.upper() in ht.upper() or
                ht.upper().endswith(batter_team.upper()) or
                batter_team.upper() in at.upper() or
                at.upper().endswith(batter_team.upper())):
                game = g
                break

        if not game:
            # Batter's team not playing today — skip
            continue

        # Determine opposing pitcher
        gpk = game["game_pk"]
        ht = game["home_team"]
        at = game["away_team"]
        venue = game["venue"]

        # Is batter on home or away?
        if batter_team.upper() in ht.upper() or ht.upper().endswith(batter_team.upper()):
            opp_pitcher_name = game.get("away_pitcher_name", "TBD")
        else:
            opp_pitcher_name = game.get("home_pitcher_name", "TBD")

        opp = slate["pitchers"].get(opp_pitcher_name, {
            "hr_per_9": 1.2, "hard_hit_pct_allowed": 35, "throws": "R"
        })

        weather = slate["weather"].get(gpk, {
            "temperature_f": 75, "wind_mph": 5, "wind_direction_deg": 0, "dome": False
        })

        # Try to get recent Statcast form data
        player_id = b.get("player_id", hash(b["name"]) % 1_000_000)
        recent = try_fetch_statcast_recent(player_id, days=14) if player_id else {}

        entry = {
            **b,
            "player_id": player_id,
            "recent_hr_14d": recent.get("recent_hr_14d", b["hr"] / 25),
            "recent_barrel_pct_14d": recent.get("recent_barrel_pct_14d", b.get("barrel_pct", 8)),
            "ev_trend_14d": recent.get("ev_trend_14d", 0),
        }

        result = compute_composite(entry, opp, venue, weather, pf, config_name)
        result["player_id"] = player_id
        result["game_pk"] = gpk
        result["opp_pitcher"] = opp_pitcher_name
        result["tier"] = tier
        result["game_venue"] = venue
        result["home_team"] = ht
        result["away_team"] = at
        all_scored.append(result)

    all_scored.sort(key=lambda x: x["composite"], reverse=True)
    return all_scored


# ---------------------------------------------------------------------------
# OFFLINE MODE — simulated slate from hardcoded data
# ---------------------------------------------------------------------------

def date_seed(date_str):
    """Deterministic seed from date string."""
    return int(hashlib.md5(date_str.encode()).hexdigest()[:8], 16)


def simulate_slate(date_str, tier, config_name, rng, pf):
    """Simulate a day's games for one tier and score all batters."""
    pitcher_lookup = {p["name"]: p for p in PITCHERS_2025}
    pitcher_names = list(pitcher_lookup.keys())
    batters = ALL_TIERS[tier]

    n_games = rng.integers(12, 16)
    venues = list(VENUES)
    rng.shuffle(venues)
    all_scored = []

    for g in range(min(n_games, 15)):
        _, venue = venues[g % len(venues)]
        hp_name = rng.choice(pitcher_names)
        ap_name = rng.choice(pitcher_names)
        gpk = int(rng.integers(1_000_000, 9_999_999))

        is_dome = venue in DOME_STADIUMS
        weather = {
            "temperature_f": 72.0 if is_dome else float(rng.normal(62, 8)),
            "wind_mph": 0.0 if is_dome else float(max(0, rng.normal(8, 5))),
            "wind_direction_deg": 0 if is_dome else int(rng.integers(0, 360)),
            "dome": is_dome,
        }

        available = list(batters)
        rng.shuffle(available)
        home = available[:5]
        away = available[5:10]

        for lineup, opp_name in [(away, hp_name), (home, ap_name)]:
            opp = pitcher_lookup.get(
                opp_name,
                {"hr_per_9": 1.2, "hard_hit_pct_allowed": 35, "throws": "R"},
            )
            for b in lineup:
                entry = {
                    **b,
                    "player_id": hash(b["name"]) % 1_000_000,
                    "recent_hr_14d": float(
                        min(5, max(0, b["hr"] / 25 + rng.normal(0, 0.8)))
                    ),
                    "recent_barrel_pct_14d": float(
                        max(0, b.get("barrel_pct", 8) + rng.normal(0, 3))
                    ),
                    "ev_trend_14d": float(rng.normal(0, 1.5)),
                }
                result = compute_composite(entry, opp, venue, weather, pf, config_name)
                result["player_id"] = entry["player_id"]
                result["game_pk"] = gpk
                result["opp_pitcher"] = opp_name
                result["tier"] = tier
                all_scored.append(result)

    all_scored.sort(key=lambda x: x["composite"], reverse=True)
    return all_scored


# ---------------------------------------------------------------------------
# Card generation — works for both live and offline
# ---------------------------------------------------------------------------

def generate_card(date_str, combo=(3, 2, 3), force_offline=False):
    """
    Generate the full 8-pick card with tier blending.
    Tries live API data first; falls back to offline simulation.
    """
    pf = get_hardcoded_park_factors()
    mode = "offline_simulation"
    live_slate = None

    if not force_offline:
        print("\n  Attempting live data fetch...")
        live_slate = fetch_live_slate(date_str)
        if live_slate and live_slate["games"]:
            mode = "live"
            print(f"  Using LIVE data ({len(live_slate['games'])} games)")
        else:
            print("  Live fetch failed or no games — falling back to offline mode")
            live_slate = None

    if not live_slate:
        print("  Using OFFLINE simulated slate")

    card = []
    tier_details = {}
    seed = date_seed(date_str)
    rng = np.random.default_rng(seed)

    for tier, count in [(1, combo[0]), (2, combo[1]), (3, combo[2])]:
        if count == 0:
            continue
        config = TIER_CONFIGS[tier]

        if live_slate:
            scored = score_live_slate(live_slate, date_str, tier, config, pf)
        else:
            scored = simulate_slate(date_str, tier, config, rng, pf)

        if not scored:
            print(f"  WARNING: No batters scored for tier {tier} — "
                  f"team may have off day. Falling back to offline.")
            scored = simulate_slate(date_str, tier, config, rng, pf)

        picks = select_top_picks(scored, n=count, max_per_game=2)

        tier_label = {1: "T1-Chalk", 2: "T2-Mid", 3: "T3-Longshot"}[tier]
        for p in picks:
            p["tier_label"] = tier_label
            p["tier_pts"] = TIER_POINTS[tier]
            card.append(p)

        tier_details[tier] = {
            "config": config,
            "picks": count,
            "top_scorer": picks[0]["name"] if picks else "N/A",
            "top_composite": picks[0]["composite"] if picks else 0,
            "pool_size": len(scored),
        }

    # Sort: T1 first, then T2, then T3; within each by composite desc
    card.sort(key=lambda x: (x.get("tier", 0), -x["composite"]))

    return card, tier_details, mode


def format_card(card, date_str, combo, tier_details, mode):
    """Pretty-print the parlay card."""
    mode_label = "LIVE" if mode == "live" else "OFFLINE (simulated matchups)"
    lines = []
    lines.append("")
    lines.append("=" * 76)
    lines.append(f"  DAILY HR PARLAY CARD — {date_str}")
    lines.append(f"  Mode: {mode_label}")
    lines.append(f"  Blend: {combo[0]}/{combo[1]}/{combo[2]} "
                 f"(T1={TIER_CONFIGS[1]}, T2={TIER_CONFIGS[2]}, T3={TIER_CONFIGS[3]})")
    lines.append(f"  Max pts if all hit: "
                 f"{sum(TIER_POINTS[c.get('tier', 1)] for c in card)}")
    lines.append("=" * 76)
    lines.append("")
    lines.append(f"  {'#':<3} {'Player':<22} {'Team':<5} {'Tier':<13} "
                 f"{'vs Pitcher':<18} {'Venue':<26} {'Score':>6} {'Pts':>4}")
    lines.append(f"  {'-' * 95}")

    for i, p in enumerate(card, 1):
        opp_p = p.get("opp_pitcher", "N/A")
        if len(opp_p) > 16:
            opp_p = opp_p[:15] + "."
        lines.append(
            f"  {i:<3} {p['name']:<22} {p['team']:<5} {p.get('tier_label', ''):<13} "
            f"{opp_p:<18} {p['venue']:<26} {p['composite']:>5.1f} {p.get('tier_pts', 1):>4}"
        )

    lines.append("")
    lines.append("  Factor Scores:")
    lines.append(f"  {'#':<3} {'Player':<22} {'Power':>7} {'Match':>7} {'Park':>7} {'Form':>7} {'Weath':>7}")
    lines.append(f"  {'-' * 60}")
    for i, p in enumerate(card, 1):
        lines.append(
            f"  {i:<3} {p['name']:<22} {p['power_score']:>6.1f} {p['matchup_score']:>6.1f} "
            f"{p['park_score']:>6.1f} {p['form_score']:>6.1f} {p['weather_score']:>6.1f}"
        )

    lines.append("")
    lines.append("  Tier Breakdown:")
    for tier in [1, 2, 3]:
        if tier in tier_details:
            d = tier_details[tier]
            tier_name = {1: "T1-Chalk", 2: "T2-Mid", 3: "T3-Longshot"}[tier]
            lines.append(
                f"    {tier_name}: {d['picks']} picks | "
                f"config={d['config']} | "
                f"pool={d['pool_size']} scored | "
                f"top={d['top_scorer']} ({d['top_composite']:.1f})"
            )

    if mode != "live":
        lines.append("")
        lines.append("  NOTE: Running in OFFLINE mode with simulated matchups.")
        lines.append("  For live picks, run from a machine with internet access:")
        lines.append("    python generate_picks.py --date YYYY-MM-DD")
        lines.append("  Requires: pip install pybaseball pandas numpy requests")

    lines.append("=" * 76)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Generate daily HR parlay card (live or offline)"
    )
    parser.add_argument(
        "--date", default="today",
        help="Date (YYYY-MM-DD or 'today', default: today)"
    )
    parser.add_argument(
        "--combo", default="3,2,3",
        help="Tier blend as T1,T2,T3 (default: 3,2,3)"
    )
    parser.add_argument(
        "--offline", action="store_true",
        help="Force offline mode (skip live API calls)"
    )
    parser.add_argument(
        "--output", default=None,
        help="Output JSON path"
    )
    args = parser.parse_args()

    if args.date == "today":
        date_str = datetime.now().strftime("%Y-%m-%d")
    else:
        date_str = args.date

    combo = tuple(int(x) for x in args.combo.split(","))
    assert sum(combo) == 8, f"Combo must sum to 8, got {sum(combo)}"

    card, tier_details, mode = generate_card(date_str, combo, force_offline=args.offline)
    output = format_card(card, date_str, combo, tier_details, mode)
    print(output)

    # Save JSON
    if args.output:
        out_path = args.output
    else:
        results_dir = Path(__file__).parent.parent / "results"
        results_dir.mkdir(parents=True, exist_ok=True)
        out_path = str(results_dir / f"picks_{date_str}.json")

    pick_data = {
        "date": date_str,
        "mode": mode,
        "combo": list(combo),
        "tier_configs": {str(k): v for k, v in TIER_CONFIGS.items()},
        "picks": [
            {
                "rank": i + 1,
                "name": p["name"],
                "team": p["team"],
                "bats": p["bats"],
                "tier": p.get("tier", 0),
                "tier_label": p.get("tier_label", ""),
                "venue": p["venue"],
                "opp_pitcher": p.get("opp_pitcher", ""),
                "composite": p["composite"],
                "power_score": p["power_score"],
                "matchup_score": p["matchup_score"],
                "park_score": p["park_score"],
                "form_score": p["form_score"],
                "weather_score": p["weather_score"],
                "tier_pts": p.get("tier_pts", 1),
            }
            for i, p in enumerate(card)
        ],
        "tier_details": {str(k): v for k, v in tier_details.items()},
        "generated_at": datetime.now().isoformat(),
    }
    with open(out_path, "w") as f:
        json.dump(pick_data, f, indent=2)
    print(f"\n  JSON saved to {out_path}")


if __name__ == "__main__":
    main()