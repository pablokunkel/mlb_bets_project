#!/usr/bin/env python3
"""
fetch_daily_data.py — Data collection for Daily HR Bet skill.

Pulls game schedules, lineups, pitcher data, batter stats, park factors,
and weather from MLB Stats API, pybaseball (Statcast/FanGraphs), and Open-Meteo.

Usage:
    python fetch_daily_data.py --date today
    python fetch_daily_data.py --date 2024-07-15
    python fetch_daily_data.py --season 2024  # bulk fetch for backtesting
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

import requests

# pybaseball imports
try:
    import pybaseball
    from pybaseball import (
        statcast,
        statcast_batter,
        batting_stats,
        pitching_stats,
        cache,
    )
    cache.enable()
except ImportError:
    print("ERROR: pybaseball not installed. Run: pip install pybaseball --break-system-packages")
    sys.exit(1)

import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MLB_STATS_API = "https://statsapi.mlb.com/api/v1"

# Venue ID → name mapping for dome detection
DOME_STADIUMS = {
    "Tropicana Field", "Chase Field", "American Family Field",
    "Minute Maid Park", "Globe Life Field", "Rogers Centre",
    "T-Mobile Park", "loanDepot park",
}

# Venue coordinates for weather lookups
VENUE_COORDS = {
    "Angel Stadium": (33.8003, -117.8827),
    "Busch Stadium": (38.6226, -90.1928),
    "Chase Field": (33.4453, -112.0667),
    "Citi Field": (40.7571, -73.8458),
    "Citizens Bank Park": (39.9061, -75.1665),
    "Comerica Park": (42.3390, -83.0485),
    "Coors Field": (39.7559, -104.9942),
    "Dodger Stadium": (34.0739, -118.2400),
    "Fenway Park": (42.3467, -71.0972),
    "Globe Life Field": (32.7473, -97.0845),
    "Great American Ball Park": (39.0975, -84.5069),
    "Guaranteed Rate Field": (41.8299, -87.6338),
    "Kauffman Stadium": (39.0517, -94.4803),
    "loanDepot park": (25.7781, -80.2197),
    "Minute Maid Park": (29.7573, -95.3555),
    "Nationals Park": (38.8730, -77.0074),
    "Oakland Coliseum": (37.7516, -122.2005),
    "Oracle Park": (37.7786, -122.3893),
    "Oriole Park at Camden Yards": (39.2838, -76.6216),
    "Petco Park": (32.7076, -117.1570),
    "PNC Park": (40.4469, -80.0058),
    "Progressive Field": (41.4962, -81.6852),
    "Rogers Centre": (43.6414, -79.3894),
    "T-Mobile Park": (47.5914, -122.3325),
    "Target Field": (44.9818, -93.2775),
    "Tropicana Field": (27.7682, -82.6534),
    "Truist Park": (33.8908, -84.4678),
    "Wrigley Field": (41.9484, -87.6553),
    "Yankee Stadium": (40.8296, -73.9262),
    "American Family Field": (43.0280, -87.9712),
}

DATA_DIR = Path(__file__).parent.parent / "data"


def ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# MLB Stats API helpers
# ---------------------------------------------------------------------------

def get_schedule(date_str: str) -> list[dict]:
    """Fetch MLB games for a given date from the Stats API."""
    url = f"{MLB_STATS_API}/schedule"
    params = {
        "sportId": 1,
        "date": date_str,
        "hydrate": "team,venue,probablePitcher,linescore",
    }
    resp = requests.get(url, params=params, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    games = []
    for date_entry in data.get("dates", []):
        for g in date_entry.get("games", []):
            game = {
                "game_pk": g["gamePk"],
                "date": date_str,
                "status": g["status"]["detailedState"],
                "home_team": g["teams"]["home"]["team"]["name"],
                "away_team": g["teams"]["away"]["team"]["name"],
                "home_team_id": g["teams"]["home"]["team"]["id"],
                "away_team_id": g["teams"]["away"]["team"]["id"],
                "venue": g.get("venue", {}).get("name", "Unknown"),
                "venue_id": g.get("venue", {}).get("id"),
                "game_time": g.get("gameDate", ""),
            }
            # Probable pitchers
            hp = g["teams"]["home"].get("probablePitcher", {})
            ap = g["teams"]["away"].get("probablePitcher", {})
            game["home_pitcher_id"] = hp.get("id")
            game["home_pitcher_name"] = hp.get("fullName", "TBD")
            game["away_pitcher_id"] = ap.get("id")
            game["away_pitcher_name"] = ap.get("fullName", "TBD")
            games.append(game)
    return games


def get_game_boxscore(game_pk: int) -> dict:
    """Fetch boxscore for a completed game (used in backtesting)."""
    url = f"{MLB_STATS_API}/game/{game_pk}/boxscore"
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    return resp.json()


def get_roster(team_id: int, date_str: str) -> list[dict]:
    """Fetch active roster for a team."""
    url = f"{MLB_STATS_API}/teams/{team_id}/roster"
    params = {"rosterType": "active", "date": date_str}
    resp = requests.get(url, params=params, timeout=15)
    resp.raise_for_status()
    roster = []
    for p in resp.json().get("roster", []):
        if p.get("position", {}).get("abbreviation") != "P":
            roster.append({
                "player_id": p["person"]["id"],
                "name": p["person"]["fullName"],
                "position": p.get("position", {}).get("abbreviation", ""),
                "bats": p.get("person", {}).get("batSide", {}).get("code", "R"),
            })
    return roster


# ---------------------------------------------------------------------------
# Weather via Open-Meteo
# ---------------------------------------------------------------------------

def get_weather(venue_name: str, game_time_iso: str) -> dict:
    """Fetch weather for a venue at game time using Open-Meteo."""
    if venue_name in DOME_STADIUMS:
        return {"temperature_f": 72, "wind_mph": 0, "wind_direction": "none", "dome": True}

    coords = VENUE_COORDS.get(venue_name)
    if not coords:
        return {"temperature_f": 75, "wind_mph": 5, "wind_direction": "unknown", "dome": False}

    lat, lon = coords
    try:
        dt = datetime.fromisoformat(game_time_iso.replace("Z", "+00:00"))
        date_str = dt.strftime("%Y-%m-%d")

        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": lat,
            "longitude": lon,
            "hourly": "temperature_2m,windspeed_10m,winddirection_10m",
            "start_date": date_str,
            "end_date": date_str,
            "temperature_unit": "fahrenheit",
            "windspeed_unit": "mph",
            "timezone": "America/New_York",
        }
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        hourly = resp.json().get("hourly", {})

        # Find closest hour to game time
        game_hour = dt.hour
        idx = min(game_hour, len(hourly.get("temperature_2m", [])) - 1)

        temps = hourly.get("temperature_2m", [75])
        winds = hourly.get("windspeed_10m", [5])
        wind_dirs = hourly.get("winddirection_10m", [0])

        return {
            "temperature_f": temps[idx] if idx < len(temps) else 75,
            "wind_mph": winds[idx] if idx < len(winds) else 5,
            "wind_direction_deg": wind_dirs[idx] if idx < len(wind_dirs) else 0,
            "dome": False,
        }
    except Exception:
        return {"temperature_f": 75, "wind_mph": 5, "wind_direction_deg": 0, "dome": False}


# ---------------------------------------------------------------------------
# Statcast / pybaseball helpers
# ---------------------------------------------------------------------------

def get_statcast_batter_stats(season: int, min_pa: int = 50) -> pd.DataFrame:
    """
    Pull season-level batter stats from FanGraphs via pybaseball.
    Returns DataFrame with key power metrics.
    """
    print(f"  Fetching FanGraphs batting stats for {season} (min {min_pa} PA)...")
    try:
        df = batting_stats(season, qual=min_pa)
        # Standardize column names
        cols_map = {
            "IDfg": "fg_id", "Name": "name", "Team": "team",
            "PA": "pa", "HR": "hr", "AB": "ab",
            "Barrel%": "barrel_pct", "HardHit%": "hard_hit_pct",
            "HR/FB": "hr_fb_pct", "ISO": "iso",
            "wOBA": "woba", "wRC+": "wrc_plus",
            "Exit Velocity (avg)": "exit_velo",
            "FB%": "fb_pct",
        }
        # Only rename columns that exist
        rename = {k: v for k, v in cols_map.items() if k in df.columns}
        df = df.rename(columns=rename)

        # Try to find barrel% and exit velo under alternate names
        if "barrel_pct" not in df.columns and "Barrel%" in df.columns:
            df["barrel_pct"] = df["Barrel%"]
        if "exit_velo" not in df.columns:
            for col in ["EV", "Exit Velocity", "HardHit"]:
                if col in df.columns:
                    df["exit_velo"] = df[col]
                    break

        return df
    except Exception as e:
        print(f"  Warning: Could not fetch batting stats: {e}")
        return pd.DataFrame()


def get_statcast_pitcher_stats(season: int, min_ip: int = 20) -> pd.DataFrame:
    """Pull pitcher stats from FanGraphs."""
    print(f"  Fetching FanGraphs pitching stats for {season} (min {min_ip} IP)...")
    try:
        df = pitching_stats(season, qual=min_ip)
        cols_map = {
            "IDfg": "fg_id", "Name": "name", "Team": "team",
            "IP": "ip", "HR/9": "hr_per_9", "ERA": "era",
            "HardHit%": "hard_hit_pct_allowed", "K/9": "k_per_9",
            "BB/9": "bb_per_9", "FIP": "fip",
        }
        rename = {k: v for k, v in cols_map.items() if k in df.columns}
        df = df.rename(columns=rename)
        return df
    except Exception as e:
        print(f"  Warning: Could not fetch pitching stats: {e}")
        return pd.DataFrame()


def get_park_factors_data(season: int) -> pd.DataFrame:
    """Pull park factors from pybaseball/FanGraphs."""
    print(f"  Fetching park factors for {season}...")
    try:
        # pybaseball park_factors returns a DataFrame
        # We'll use FanGraphs park factors
        # Fallback: hardcoded recent park factors
        pf = get_hardcoded_park_factors()
        return pf
    except Exception as e:
        print(f"  Warning: Could not fetch park factors: {e}")
        return get_hardcoded_park_factors()


def get_hardcoded_park_factors() -> pd.DataFrame:
    """Hardcoded 2022-2024 rolling HR park factors as fallback."""
    data = {
        "venue": [
            "Coors Field", "Great American Ball Park", "Yankee Stadium",
            "Globe Life Field", "Fenway Park", "Wrigley Field",
            "Citizens Bank Park", "Dodger Stadium", "Truist Park",
            "Guaranteed Rate Field", "Busch Stadium", "Minute Maid Park",
            "Target Field", "Kauffman Stadium", "Angel Stadium",
            "Citi Field", "PNC Park", "Comerica Park",
            "Nationals Park", "Progressive Field", "Petco Park",
            "American Family Field", "Oriole Park at Camden Yards",
            "T-Mobile Park", "Rogers Centre", "Chase Field",
            "Tropicana Field", "loanDepot park", "Oracle Park",
            "Oakland Coliseum",
        ],
        "hr_park_factor": [
            130, 118, 115, 112, 110, 108, 107, 105, 104, 103,
            102, 106, 101, 100, 99, 98, 95, 96, 103, 97,
            92, 105, 108, 93, 107, 104, 96, 90, 82, 88,
        ],
    }
    return pd.DataFrame(data)


def get_recent_statcast(player_id: int, days: int = 14) -> pd.DataFrame:
    """Pull recent Statcast batted-ball data for a player (last N days)."""
    end = datetime.now()
    start = end - timedelta(days=days)
    try:
        df = statcast_batter(
            start.strftime("%Y-%m-%d"),
            end.strftime("%Y-%m-%d"),
            player_id,
        )
        return df
    except Exception:
        return pd.DataFrame()


# ---------------------------------------------------------------------------
# Aggregate fetch for a single date
# ---------------------------------------------------------------------------

def fetch_for_date(date_str: str, season: int = None) -> dict:
    """
    Master fetch function: pulls all data needed for scoring on a given date.
    Returns a dict with games, batters, pitchers, park_factors, weather.
    """
    if season is None:
        season = int(date_str[:4])

    print(f"\n{'='*60}")
    print(f"Fetching data for {date_str}")
    print(f"{'='*60}")

    # 1. Schedule
    print("  Fetching schedule...")
    games = get_schedule(date_str)
    print(f"  Found {len(games)} games")

    if not games:
        return {"date": date_str, "games": [], "batters": [], "pitchers": [],
                "park_factors": pd.DataFrame(), "weather": {}}

    # 2. Season-level batter stats
    batter_stats = get_statcast_batter_stats(season)

    # 3. Season-level pitcher stats
    pitcher_stats = get_statcast_pitcher_stats(season)

    # 4. Park factors
    park_factors_df = get_park_factors_data(season)

    # 5. Weather for each game
    weather_data = {}
    for g in games:
        venue = g["venue"]
        game_time = g.get("game_time", "")
        weather_data[g["game_pk"]] = get_weather(venue, game_time)

    return {
        "date": date_str,
        "season": season,
        "games": games,
        "batter_stats": batter_stats,
        "pitcher_stats": pitcher_stats,
        "park_factors": park_factors_df,
        "weather": weather_data,
    }


# ---------------------------------------------------------------------------
# Bulk fetch for backtesting a full season
# ---------------------------------------------------------------------------

def fetch_season(season: int, sample_days: int = None) -> list[str]:
    """
    Fetch schedule for every day of an MLB season.
    Returns list of dates that had games.
    If sample_days is set, randomly samples that many game-dates.
    """
    # MLB regular season: ~late March to late September
    start = datetime(season, 3, 28)
    end = datetime(season, 9, 29)

    print(f"Scanning {season} season for game dates...")
    all_dates = []
    current = start
    while current <= end:
        date_str = current.strftime("%Y-%m-%d")
        try:
            games = get_schedule(date_str)
            if games:
                all_dates.append(date_str)
        except Exception:
            pass
        current += timedelta(days=1)
        time.sleep(0.1)  # rate limiting

    print(f"Found {len(all_dates)} game dates in {season}")

    if sample_days and sample_days < len(all_dates):
        rng = np.random.default_rng(42)
        all_dates = sorted(rng.choice(all_dates, sample_days, replace=False).tolist())
        print(f"Sampled {sample_days} dates for backtesting")

    return all_dates


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Fetch MLB data for HR parlay scoring")
    parser.add_argument("--date", default="today", help="Date (YYYY-MM-DD or 'today')")
    parser.add_argument("--season", type=int, help="Fetch full season for backtesting")
    parser.add_argument("--output", default=None, help="Output JSON path")
    args = parser.parse_args()

    if args.season:
        dates = fetch_season(args.season)
        output_path = args.output or str(DATA_DIR / f"season_{args.season}_dates.json")
        ensure_data_dir()
        with open(output_path, "w") as f:
            json.dump(dates, f, indent=2)
        print(f"Saved {len(dates)} game dates to {output_path}")
    else:
        if args.date == "today":
            date_str = datetime.now().strftime("%Y-%m-%d")
        else:
            date_str = args.date

        data = fetch_for_date(date_str)
        output_path = args.output or str(DATA_DIR / f"daily_{date_str}.json")
        ensure_data_dir()

        # Serialize — convert DataFrames to dicts
        serializable = {
            "date": data["date"],
            "games": data["games"],
            "weather": data["weather"],
            "batter_count": len(data.get("batter_stats", [])),
            "pitcher_count": len(data.get("pitcher_stats", [])),
        }
        with open(output_path, "w") as f:
            json.dump(serializable, f, indent=2, default=str)
        print(f"Saved daily data to {output_path}")


if __name__ == "__main__":
    main()